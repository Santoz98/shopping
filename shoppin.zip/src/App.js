import React, { useState} from 'react';
import './index.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight, faChevronLeft, faCircle, faCheckCircle, faPlus } from '@fortawesome/free-solid-svg-icons';

const App = () => {
	// HINT: each "item" in our list names a name, a boolean to tell if its been completed, and a quantity
	const [items, setItems] = useState([
		// { itemName: 'item 1', quantity: 1, isSelected: false },
		// { itemName: 'item 2', quantity: 3, isSelected: true },
		// { itemName: 'item 3', quantity: 2, isSelected: false },
	]);

	const [totalcount,setTotalCount] =useState(0)
	const [itemValue,setItemValue]=useState('')
	const setIncrement=(index)=>{
		  const newitem = [...items]
			newitem[index].quantity++;
			setItems(newitem)
			calculateTotal(newitem)

	}
	const setDecrement=(remindex)=>{
			const newitem = [...items]
			
			if(newitem[remindex].quantity>1){
				newitem[remindex].quantity--;
				setItems(newitem)
				calculateTotal(newitem)
			}
			else{
				

				const newitem = [...items]
				newitem.splice(remindex,1)
				
				setItems(newitem)
				calculateTotal(newitem)


			}
			


	}

	const handleButtonClick=()=>{
	   const newItem ={
		    itemName: itemValue, quantity: 1, isSelected: false 
	   }
	   const newItems = [...items,newItem]
	   setItems(newItems)
	   calculateTotal(newItems)
	   setItemValue('')
	   

   }
	const calculateTotal=(newItems)=>{
		const total = newItems.reduce((total,item)=>{
			return total+item.quantity

		},0)
		

		setTotalCount(total)

	}
   const changetoggle=(index)=>{
	   const newitem = [...items]
			newitem[index].isSelected=!newitem[index].isSelected;
			setItems(newitem)
   }

   


	return (
		<div className='app-background'>
			<div className='main-container'>
				<div className='add-item-box'>
					<input className='add-item-input' placeholder='Add an item...' value={itemValue} onChange={(event)=>setItemValue(event.target.value)} />
					<FontAwesomeIcon icon={faPlus} onClick={handleButtonClick} />
				</div>
				<div className='item-list'>
					{
						items.map((item,index) => (
							<div className='item-container'>
						<div className='item-name'>
							{/* HINT: replace false with a boolean indicating the item has been completed or not */}
							{item.isSelected ? (
								<>
									<FontAwesomeIcon icon={faCheckCircle} onClick={()=>{changetoggle(index)}} />
							<span className='completed'>{item.itemName}</span>
								</>
							) : (
								<>
									<FontAwesomeIcon icon={faCircle} onClick={()=>{changetoggle(index)}} />
							<span>{item.itemName}</span>
								</>
							)}
						</div>
						{item.isSelected ?(
							<div className='quantity graded'>
							<button>
								<FontAwesomeIcon icon={faChevronLeft} />
							</button>
							<span> {item.quantity} </span>
							<button>
								<FontAwesomeIcon icon={faChevronRight}  />
							</button>
						</div>):
						(
							<div className='quantity'>
							<button>
								<FontAwesomeIcon icon={faChevronLeft} onClick={()=>{setDecrement(index)}}/>
							</button>
							<span> {item.quantity} </span>
							<button>
								<FontAwesomeIcon icon={faChevronRight} onClick={()=>{setIncrement(index)}} />
							</button>
						</div>
						)
						}
						
					</div>
						))
					}
					
				</div>
				<div className='total'>Total: {totalcount}</div>
			</div>
		</div>
	);
};

export default App;
